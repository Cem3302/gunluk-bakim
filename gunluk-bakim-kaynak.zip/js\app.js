/* Günlük Bakım — Daily Maintenance Tracker
   Sayfa mantığı: Bugün / Geçmiş / Ekipmanlar / Ayarlar
   Veri: localStorage, dille TR/EN */
(function () {
  'use strict';

  const OILS = ['15W-40', '68', 'ACX30', 'ACX50', '80W-90', '85W-90', 'ATF DIII', 'COOL ELF', '85W-140'];
  const STORE = 'gunlukBakim.v1';
  const EN_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  /* ================= yardımcılar ================= */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad = n => String(n).padStart(2, '0');
  const todayISO = () => { const d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  const parseISO = iso => { const p = String(iso).split('-').map(Number); return Date.UTC(p[0], p[1] - 1, p[2]); };
  const diffDays = (a, b) => Math.round((parseISO(b) - parseISO(a)) / 86400000);
  const addDays = (iso, n) => { const dt = new Date(parseISO(iso) + n * 86400000); return dt.getUTCFullYear() + '-' + pad(dt.getUTCMonth() + 1) + '-' + pad(dt.getUTCDate()); };
  const bi = (trStr, enStr) => (state.lang === 'en' ? enStr : trStr);

  const PAGES = ['today', 'faults', 'tyres', 'history', 'equipment', 'settings'];
  function rememberPage(p) {
    try { localStorage.setItem('gunlukBakim.page', p); } catch (e) { /* yoksay */ }
    if (location.hash.slice(1) !== p) history.replaceState(null, '', '#' + p);
  }
  function pageFromStart() {
    const h = location.hash.slice(1);
    if (PAGES.indexOf(h) !== -1) return h;
    try {
      const s = localStorage.getItem('gunlukBakim.page');
      if (PAGES.indexOf(s) !== -1) return s;
    } catch (e) { /* yoksay */ }
    return 'today';
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    const p = iso.split('-');
    return state.lang === 'en' ? EN_MONTHS[+p[1] - 1] + ' ' + (+p[2]) + ', ' + p[0] : p[2] + '.' + p[1] + '.' + p[0];
  }
  function fmtShort(iso) { const p = iso.split('-'); return state.lang === 'en' ? (+p[1]) + '/' + (+p[2]) : p[2] + '.' + p[1]; }
  function t(key, vars) {
    const dict = window.I18N[state.lang] || window.I18N.tr;
    let s = dict[key];
    if (s == null) s = window.I18N.tr[key] || key;
    if (vars) for (const k in vars) s = s.split('{' + k + '}').join(String(vars[k]));
    return s;
  }
  function tType(raw) { if (!raw) return ''; return state.lang === 'tr' ? (window.TYPE_TR[raw] || raw) : raw; }

  /* ================= durum ================= */
  let state = null;
  const cache = { status: null, saveTimer: null, savedTimer: null, toastTimer: null };
  const ui = {
    page: 'today',
    date: todayISO(),
    search: '', type: '', onlyMissing: false,
    histView: 'days', histFrom: '', histTo: '', histSearch: '',
    eqSearch: '', eqType: '',
    faultSearch: '', faultFilter: '',
    tyreSearch: '', tyreFrom: '', tyreTo: '',
    alertsExpanded: false,
    refocus: null
  };

  function seedEquipment() {
    return (window.EQUIPMENT_SEED || []).map(e => ({ id: e.n, n: e.n, t: e.t, b: e.b, m: e.m, s: e.s }));
  }
  function defaultState() {
    return { lang: 'tr', settings: { warnDays: 2 }, equipment: seedEquipment(), removed: [], records: {}, faults: [], tyres: [] };
  }
  function load() {
    try {
      const raw = localStorage.getItem(STORE);
      if (raw) {
        const st = JSON.parse(raw);
        if (st && Array.isArray(st.equipment)) {
          st.settings = Object.assign({ warnDays: 2 }, st.settings || {});
          st.removed = Array.isArray(st.removed) ? st.removed : [];
          st.records = st.records && typeof st.records === 'object' ? st.records : {};
          st.faults = Array.isArray(st.faults) ? st.faults : [];
          st.tyres = Array.isArray(st.tyres) ? st.tyres : [];
          st.lang = st.lang === 'en' ? 'en' : 'tr';
          return st;
        }
      }
    } catch (e) { /* bozuk kayıt -> sıfırdan */ }
    return defaultState();
  }
  function prune() {
    for (const d in state.records) {
      const r = state.records[d];
      if (!r || typeof r !== 'object') { delete state.records[d]; continue; }
      r.items = r.items || {};
      for (const id in r.items) {
        const it = r.items[id];
        const has = it.v || it.g || it.af || (it.o && Object.keys(it.o).length) || it.h || it.loc || it.ob;
        if (!has) delete r.items[id];
      }
      if (!r.attender && !Object.keys(r.items).length && (r.shift === 'day' || !r.shift)) delete state.records[d];
    }
  }
  function save(now) {
    clearTimeout(cache.saveTimer);
    cache.status = null; /* durum anında tazelensin (KPI/uyarılar) */
    const doSave = () => {
      prune();
      try {
        localStorage.setItem(STORE, JSON.stringify(state));
        flashSaved();
      } catch (e) {
        toast(bi('Kayıt alanı doldu! Eski kayıtları CSV ile indirip temizleyin.', 'Storage full! Export CSV and clean old records.'), 'err', 4200);
      }
    };
    if (now) doSave(); else cache.saveTimer = setTimeout(doSave, 400);
  }
  function flashSaved() {
    const el = $('#savedNote');
    if (!el) return;
    el.classList.add('show');
    clearTimeout(cache.savedTimer);
    cache.savedTimer = setTimeout(() => el.classList.remove('show'), 1400);
  }
  function toast(msg, kind, ms) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast show' + (kind ? ' ' + kind : '');
    clearTimeout(cache.toastTimer);
    cache.toastTimer = setTimeout(() => el.classList.remove('show'), ms || 2200);
  }

  function getRecord(d, create) {
    if (!state.records[d]) {
      if (!create) return null;
      state.records[d] = { attender: '', shift: 'day', items: {} };
    }
    const r = state.records[d];
    r.items = r.items || {};
    return r;
  }
  function getItem(d, id, create) {
    const r = getRecord(d, create);
    if (!r) return null;
    if (!r.items[id]) {
      if (!create) return null;
      r.items[id] = { v: 0, g: 0, af: 0, o: {}, h: '', loc: '', ob: '' };
    }
    const it = r.items[id];
    it.o = it.o || {};
    return it;
  }

  /* ================= durum hesapları ================= */
  function computeStatuses() {
    const recs = state.records;
    const dates = Object.keys(recs).sort();
    const last = {};
    let firstVisit = null;
    for (const d of dates) {
      const items = (recs[d] && recs[d].items) || {};
      let any = false;
      for (const id in items) { if (items[id].v) { last[id] = d; any = true; } }
      if (any && !firstVisit) firstVisit = d;
    }
    const today = todayISO();
    const warnDays = Math.max(1, parseInt(state.settings.warnDays, 10) || 2);
    const out = { last: last, byEq: {}, warnCount: 0, firstVisit: firstVisit };
    for (const eq of state.equipment) {
      const l = last[eq.id] || null;
      let missed = 0, st;
      if (l) {
        missed = Math.max(0, diffDays(l, today));
        st = missed >= warnDays ? 'warn' : (missed === 0 ? 'today' : (missed === 1 ? 'pending' : 'ok'));
      } else {
        const start = (eq.createdAt && firstVisit && eq.createdAt > firstVisit) ? eq.createdAt : firstVisit;
        if (start) { missed = Math.max(0, diffDays(start, today) + 1); st = missed >= warnDays ? 'warn' : 'never'; }
        else { missed = 0; st = 'never'; }
      }
      out.byEq[eq.id] = { last: l, missed: missed, st: st };
      if (st === 'warn') out.warnCount++;
    }
    return out;
  }
  function statuses() { if (!cache.status) cache.status = computeStatuses(); return cache.status; }

  function statusChip(s) {
    if (s.st === 'today') return '<span class="chip ok">✓ ' + esc(t('okChip')) + '</span>';
    if (s.st === 'warn') return '<span class="chip danger">⚠ ' + esc(t('warnChip', { n: s.missed })) + '</span>';
    if (s.st === 'pending') return '<span class="chip warn">' + esc(t('pendingChip')) + '</span>';
    if (s.st === 'ok') return '<span class="chip warn">' + esc(t('gapDays', { n: s.missed })) + '</span>';
    return '<span class="chip neutral">' + esc(t('never')) + '</span>';
  }

  function visitsOn(d) {
    const r = state.records[d];
    if (!r) return 0;
    let n = 0;
    for (const id in r.items) if (r.items[id].v) n++;
    return n;
  }

  /* ================= filtreler ================= */
  function eqMatches(eq, q) {
    if (!q) return true;
    q = q.toLowerCase();
    return (eq.n + ' ' + eq.t + ' ' + (eq.b || '') + ' ' + (eq.m || '')).toLowerCase().indexOf(q) !== -1;
  }
  function todayFilterList() {
    const st = statuses();
    return state.equipment.filter(eq => {
      if (ui.type && eq.t !== ui.type) return false;
      if (!eqMatches(eq, ui.search)) return false;
      if (ui.onlyMissing) {
        const it = getItem(ui.date, eq.id, false);
        if (it && it.v) return false;
      }
      return true;
    });
  }

  /* ================= sayfa: bugün ================= */
  function renderToday() {
    const list = todayFilterList();
    const total = state.equipment.length;
    const types = allTypes();
    const rec = getRecord(ui.date, false);
    const isToday = ui.date === todayISO();

    const html = `
      <h1 class="page-title">${esc(t('navToday'))} — ${esc(fmtDate(ui.date))}</h1>
      <p class="page-sub">${esc(t('appSub'))}</p>

      <div class="toolbar">
        <div class="date-nav">
          <button class="btn sm" data-act="date-prev" title="${esc(t('prevDay'))}">‹</button>
          <input class="input" type="date" id="datePick" value="${esc(ui.date)}" max="${todayISO()}">
          <button class="btn sm" data-act="date-next" title="${esc(t('nextDay'))}" ${isToday ? 'disabled' : ''}>›</button>
          <button class="btn sm" data-act="date-today" ${isToday ? 'disabled' : ''}>${esc(t('today'))}</button>
        </div>
        <div class="field">
          <label>${esc(t('attender'))}</label>
          <input class="input" type="text" id="attenderInput" placeholder="${esc(t('attenderPh'))}" value="${esc(rec ? rec.attender : '')}">
        </div>
        <div class="field">
          <label>${esc(t('shift'))}</label>
          <select class="input" id="shiftSelect">
            <option value="day" ${!rec || rec.shift !== 'night' ? 'selected' : ''}>${esc(t('shiftDay'))}</option>
            <option value="night" ${rec && rec.shift === 'night' ? 'selected' : ''}>${esc(t('shiftNight'))}</option>
          </select>
        </div>
        <span class="saved-note" id="savedNote">✔ ${esc(t('saved'))}</span>
        <div class="spacer"></div>
        <button class="btn sm" data-act="mark-all">${esc(t('markAll'))}</button>
        <button class="btn sm" data-act="unmark-all">${esc(t('unmarkAll'))}</button>
        <label class="check-inline"><input type="checkbox" class="cb" id="onlyMissing" ${ui.onlyMissing ? 'checked' : ''}> ${esc(t('onlyMissing'))}</label>
        <div class="field">
          <label>${esc(t('search'))}</label>
          <input class="input" type="search" id="todaySearch" placeholder="${esc(t('searchPh'))}" value="${esc(ui.search)}" style="min-width:230px">
        </div>
        <div class="field">
          <label>${esc(t('type'))}</label>
          <select class="input" id="todayType">
            <option value="">${esc(t('allTypes'))}</option>
            ${types.map(x => `<option value="${esc(x)}" ${ui.type === x ? 'selected' : ''}>${esc(tType(x))}</option>`).join('')}
          </select>
        </div>
      </div>

      <div class="kpis" id="kpis"></div>
      <div id="alerts"></div>

      <div class="card" style="padding:0;overflow:hidden">
        <div style="padding:12px 14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;border-bottom:1px solid var(--line)">
          <h2 style="margin:0">${esc(t('navToday'))} <span class="count" id="showingCount"></span></h2>
          <span class="hint">${esc(t('noRecordsYet'))}</span>
        </div>
        <div id="todayTable"></div>
      </div>`;

    $('#main').innerHTML = html;
    renderTodayTable();
    updateTodayStats();
  }

  function renderTodayTable() {
    const list = todayFilterList();
    const total = state.equipment.length;
    const show = $('#showingCount');
    if (show) show.textContent = t('showing', { a: list.length, b: total });

    if (!list.length) {
      $('#todayTable').innerHTML = '<div class="empty"><span class="big">🔍</span>' + esc(t('noneFound')) + '</div>';
      return;
    }
    const head = `
      <thead><tr>
        <th class="c-chk" title="${esc(t('visited'))}">✓</th>
        <th class="c-no">${esc(t('equipmentNo'))}</th>
        <th class="c-type">${esc(t('type'))}</th>
        <th class="c-bm">${esc(t('brand'))} / ${esc(t('model'))}</th>
        <th>${esc(t('hours'))}</th>
        <th>${esc(t('location'))}</th>
        <th class="o-col" title="${esc(t('greasing'))}">GRS</th>
        <th class="o-col" title="${esc(t('airFilter'))}">AIR</th>
        ${OILS.map(o => `<th class="o-col">${esc(o)}</th>`).join('')}
        <th class="obs">${esc(t('observation'))}</th>
      </tr></thead>`;

    const rows = list.map(eq => {
      const it = getItem(ui.date, eq.id, false) || { v: 0, g: 0, af: 0, o: {}, h: '', loc: '', ob: '' };
      const oils = it.o || {};
      return `
      <tr data-row="${esc(eq.id)}" class="${it.v ? 'visited' : ''}">
        <td class="c-chk" title="${esc(t('visited'))}"><input type="checkbox" class="cb big" data-f="v" data-id="${esc(eq.id)}" ${it.v ? 'checked' : ''}></td>
        <td class="c-no" title="${esc(eq.n)}"><button class="row-toggle" data-act="toggle-row" data-id="${esc(eq.id)}" aria-label="${esc(t('observation'))}">›</button>${esc(eq.n)}</td>
        <td class="c-type" title="${esc(eq.t)}">${esc(tType(eq.t))}<small>${esc(eq.s || '')}</small></td>
        <td class="c-bm" title="${esc((eq.b || '') + ' ' + (eq.m || ''))}"><b>${esc(eq.b || '—')}</b><small>${esc(eq.m || '')}</small></td>
        <td data-label="${esc(t('hours'))}"><input type="text" data-f="h" data-id="${esc(eq.id)}" value="${esc(it.h)}" placeholder="${esc(t('hours'))}" style="width:86px"></td>
        <td data-label="${esc(t('location'))}"><input type="text" data-f="loc" data-id="${esc(eq.id)}" value="${esc(it.loc)}" placeholder="${esc(t('locationPh'))}" style="min-width:110px"></td>
        <td class="o-col" data-label="${esc(t('greasing'))}"><input type="checkbox" class="cb" data-f="g" data-id="${esc(eq.id)}" ${it.g ? 'checked' : ''}></td>
        <td class="o-col" data-label="${esc(t('airFilter'))}"><input type="checkbox" class="cb" data-f="af" data-id="${esc(eq.id)}" ${it.af ? 'checked' : ''}></td>
        ${OILS.map(o => {
          const ov = oils[o];
          const qty = (ov && typeof ov === 'object') ? (ov.q || '') : '';
          return `<td class="o-col" data-label="${esc(o)}"><span class="oil-cell">
            <input type="checkbox" class="cb" data-f="oil" data-oil="${esc(o)}" data-id="${esc(eq.id)}" ${ov ? 'checked' : ''}>
            <input type="number" class="oil-qty" data-f="oilq" data-oil="${esc(o)}" data-id="${esc(eq.id)}" value="${esc(qty)}" min="0" step="0.5" placeholder="${esc(t('oilQtyShort'))}" title="${esc(o)} — ${esc(t('oilQtyTitle'))}">
          </span></td>`;
        }).join('')}
        <td class="obs" data-label="${esc(t('observation'))}"><input type="text" data-f="ob" data-id="${esc(eq.id)}" value="${esc(it.ob)}" placeholder="${esc(t('observationPh'))}"></td>
      </tr>`;
    }).join('');

    $('#todayTable').innerHTML = `<div class="table-wrap"><table class="grid">${head}<tbody>${rows}</tbody></table></div>`;
  }

  function kpiBlock(cls, label, value, note) {
    return `<div class="kpi ${cls}"><div class="k-label">${esc(label)}</div><div class="k-value">${value}</div><div class="k-note">${esc(note)}</div></div>`;
  }

  function updateTodayStats() {
    const st = statuses();
    const today = todayISO();
    const warnDays = Math.max(1, parseInt(state.settings.warnDays, 10) || 2);
    const total = state.equipment.length;
    let visited = 0, warn = 0;
    for (const eq of state.equipment) {
      const s = st.byEq[eq.id];
      if (s.st === 'today') visited++;
      if (s.st === 'warn') warn++;
    }
    const yv = visitsOn(addDays(today, -1));
    const pct = total ? Math.round(visited / total * 100) : 0;

    const kpis = $('#kpis');
    if (kpis) {
      kpis.innerHTML =
        kpiBlock('ok', t('kpiVisited'), `${visited} <span style="font-size:14px;color:var(--muted)">/ ${total}</span>`, t('kpiVisitedNote', { n: total })) +
        `<div class="kpi info"><div class="k-label">${esc(t('kpiProgress'))}</div><div class="k-value">${pct}%</div><div class="progress"><i style="width:${pct}%"></i></div></div>` +
        kpiBlock('warn', t('kpiPending'), total - visited, t('kpiPendingNote')) +
        kpiBlock('danger', t('kpiWarnings'), warn, t('kpiWarningsNote', { n: warnDays })) +
        kpiBlock('info', t('kpiLastDay'), yv, t('kpiLastDayNote'));
    }

    const alertsBox = $('#alerts');
    if (alertsBox) {
      if (!warn) {
        alertsBox.innerHTML = `<div class="card" style="border-color:#bbf7d0;background:#f7fef9"><h2 style="color:var(--ok)">✔ ${esc(t('alertsEmpty'))}</h2></div>`;
      } else {
        const list = state.equipment
          .filter(eq => st.byEq[eq.id].st === 'warn')
          .sort((a, b) => st.byEq[b.id].missed - st.byEq[a.id].missed);
        const cap = ui.alertsExpanded ? list.length : 12;
        const shown = list.slice(0, cap);
        const rest = list.length - shown.length;
        alertsBox.innerHTML = `
          <div class="card alerts">
            <h2>${esc(t('alertsTitleN', { n: warn, d: warnDays }))}</h2>
            <div class="alert-list">
              ${shown.map(eq => {
                const s = st.byEq[eq.id];
                return `<div class="alert-item" data-act="jump" data-no="${esc(eq.n)}" title="${esc(t('jumpTo'))}">
                  <span class="a-no">${esc(eq.n)}</span>
                  <span class="a-type">${esc(tType(eq.t))}</span>
                  <span class="a-last">${esc(t('lastMaintenance'))}: ${s.last ? esc(fmtDate(s.last)) : '—'}</span>
                  <span class="a-days">⚠ ${esc(t('warnChip', { n: s.missed }))}</span>
                </div>`;
              }).join('')}
            </div>
            ${list.length > 12 ? `<div style="text-align:center;margin-top:10px">
              <button class="btn sm" data-act="alerts-toggle">${rest > 0 ? esc(t('alertsMore', { n: rest })) : esc(t('alertsLess'))}</button>
            </div>` : ''}
          </div>`;
      }
    }

    const badge = $('#navBadge');
    if (badge) {
      badge.textContent = warn;
      badge.style.display = warn ? '' : 'none';
    }
  }

  function allTypes() {
    const set = {};
    state.equipment.forEach(e => { if (e.t) set[e.t] = 1; });
    return Object.keys(set).sort((a, b) => a.localeCompare(b));
  }

  function focusRow(id) {
    const tr = $(`tr[data-row="${CSS.escape(id)}"]`);
    if (!tr) return;
    tr.scrollIntoView({ block: 'center', behavior: 'smooth' });
    tr.style.outline = '2px solid var(--brand2)';
    setTimeout(() => { tr.style.outline = ''; }, 1800);
  }

  /* ================= sayfa: geçmiş ================= */
  function renderHistory() {
    const dates = Object.keys(state.records).sort().reverse();
    const totalDays = dates.length;
    let totalVisits = 0;
    dates.forEach(d => { totalVisits += visitsOn(d); });

    $('#main').innerHTML = `
      <h1 class="page-title">${esc(t('historyTitle'))}</h1>
      <p class="page-sub">${esc(t('historySub'))}</p>

      <div class="kpis">
        ${kpiBlock('info', t('viewDays'), totalDays, t('dayRecords', { n: totalDays }))}
        ${kpiBlock('ok', t('kpiVisited'), totalVisits, t('statVisits'))}
        ${kpiBlock('info', t('equipmentTitle'), state.equipment.length, t('statEquip'))}
      </div>

      <div class="card">
        <h2>📊 ${esc(t('chartTitle'))}</h2>
        <div class="chart" id="chart"></div>
      </div>

      <div class="toolbar">
        <div class="lang-switch" style="background:var(--neutral-bg)">
          <button class="${ui.histView === 'days' ? 'active' : ''}" data-act="hist-view" data-view="days" style="color:inherit">${esc(t('viewDays'))}</button>
          <button class="${ui.histView === 'last' ? 'active' : ''}" data-act="hist-view" data-view="last" style="color:inherit">${esc(t('viewLast'))}</button>
        </div>
        <div class="field"><label>${esc(t('from'))}</label><input class="input" type="date" id="histFrom" value="${esc(ui.histFrom)}"></div>
        <div class="field"><label>${esc(t('to'))}</label><input class="input" type="date" id="histTo" value="${esc(ui.histTo)}"></div>
        <div class="field"><label>${esc(t('search'))}</label><input class="input" type="search" id="histSearch" placeholder="${esc(t('searchPh'))}" value="${esc(ui.histSearch)}" style="min-width:230px"></div>
        <div class="spacer"></div>
        <button class="btn" data-act="export-csv">⬇ ${esc(t('exportCsv'))}</button>
      </div>

      <div id="histList"></div>`;

    renderChart();
    renderHistList();
  }

  function renderChart() {
    const box = $('#chart');
    if (!box) return;
    const today = todayISO();
    const days = [];
    for (let i = 13; i >= 0; i--) days.push(addDays(today, -i));
    const counts = days.map(d => visitsOn(d));
    const max = Math.max(1, ...counts);
    box.innerHTML = days.map((d, i) => {
      const c = counts[i];
      const h = Math.round(c / max * 100);
      return `<div class="bar ${c ? '' : 'zero'}" title="${esc(fmtDate(d))}: ${c}">
        <span>${c || ''}</span>
        <i style="height:${Math.max(3, h)}%"></i>
        <b>${esc(fmtShort(d))}</b>
      </div>`;
    }).join('');
  }

  function histFilteredDates() {
    return Object.keys(state.records).sort().reverse().filter(d => {
      if (ui.histFrom && d < ui.histFrom) return false;
      if (ui.histTo && d > ui.histTo) return false;
      if (ui.histSearch) {
        const r = state.records[d];
        const q = ui.histSearch.toLowerCase();
        const attenderHit = (r.attender || '').toLowerCase().indexOf(q) !== -1;
        const eqHit = Object.keys(r.items).some(id => {
          const eq = eqById(id);
          return eqMatches({ n: id, t: eq ? eq.t : '', b: eq ? eq.b : '', m: eq ? eq.m : '' }, q);
        });
        if (!attenderHit && !eqHit) return false;
      }
      return true;
    });
  }

  function eqById(id) { return state.equipment.find(e => e.id === id) || null; }

  function itemDoneChips(it) {
    const chips = [];
    if (it.g) chips.push('<span class="chip ok">GRS</span>');
    if (it.af) chips.push('<span class="chip ok">AIR</span>');
    Object.keys(it.o || {}).forEach(o => {
      const v = it.o[o];
      if (!v) return;
      const q = (typeof v === 'object') ? v.q : '';
      chips.push('<span class="chip oil">' + esc(o) + (q ? ' · ' + esc(q) + ' L' : '') + '</span>');
    });
    if (!chips.length && it.v) chips.push('<span class="chip neutral">' + esc(t('visited')) + '</span>');
    if (!chips.length) chips.push('<span class="chip neutral">' + esc(t('noVisit')) + '</span>');
    return chips.join(' ');
  }

  function renderHistList() {
    const box = $('#histList');
    if (!box) return;
    if (ui.histView === 'last') return renderLastView(box);

    const dates = histFilteredDates();
    if (!Object.keys(state.records).length) {
      box.innerHTML = `<div class="card"><div class="empty"><span class="big">🗂️</span>${esc(t('emptyHistory'))}</div></div>`;
      return;
    }
    if (!dates.length) {
      box.innerHTML = `<div class="card"><div class="empty"><span class="big">🔍</span>${esc(t('noMatchingDays'))}</div></div>`;
      return;
    }
    box.innerHTML = dates.map(d => {
      const r = state.records[d];
      const ids = Object.keys(r.items);
      const vc = ids.filter(id => r.items[id].v).length;
      const rows = ids.map(id => {
        const it = r.items[id];
        const eq = eqById(id);
        return `<tr>
          <td data-label="${esc(t('equipmentNo'))}" style="font-weight:700">${esc(id)}</td>
          <td data-label="${esc(t('type'))}">${esc(eq ? tType(eq.t) : '')}</td>
          <td data-label="${esc(t('hours'))}">${esc(it.h || '—')}</td>
          <td data-label="${esc(t('location'))}">${esc(it.loc || '—')}</td>
          <td class="num" data-label="${esc(t('greasing'))}">${it.g ? '✔' : ''}</td>
          <td class="num" data-label="${esc(t('airFilter'))}">${it.af ? '✔' : ''}</td>
          <td data-label="${esc(t('detailsDone'))}">${itemDoneChips(it)}</td>
          <td data-label="${esc(t('observation'))}">${esc(it.ob || '')}</td>
        </tr>`;
      }).join('');
      return `
      <details class="day-card">
        <summary>
          <span class="d-date">${esc(fmtDate(d))}</span>
          <span class="d-meta">👤 ${esc(r.attender || '—')}</span>
          <span class="d-meta">🕐 ${esc(r.shift === 'night' ? t('shiftNight') : t('shiftDay'))}</span>
          <span class="chip ok">${esc(t('visitedCount', { n: vc }))}</span>
          <span class="d-caret">›</span>
        </summary>
        <div class="d-body">
          <table class="grid compact" style="min-width:900px">
            <thead><tr>
              <th>${esc(t('equipmentNo'))}</th><th>${esc(t('type'))}</th><th>${esc(t('hours'))}</th><th>${esc(t('location'))}</th>
              <th class="num">${esc(t('greasing'))}</th><th class="num">${esc(t('airFilter'))}</th>
              <th>${esc(t('detailsDone'))}</th><th>${esc(t('observation'))}</th>
            </tr></thead>
            <tbody>${rows || '<tr><td colspan="8" class="empty">' + esc(t('noVisit')) + '</td></tr>'}</tbody>
          </table>
        </div>
      </details>`;
    }).join('');
  }

  function renderLastView(box) {
    const st = statuses();
    const q = ui.histSearch;
    const rows = state.equipment
      .filter(eq => eqMatches(eq, q))
      .map(eq => ({ eq: eq, s: st.byEq[eq.id] }))
      .filter(x => !ui.histFrom || !x.s.last || x.s.last >= ui.histFrom)
      .sort((a, b) => b.s.missed - a.s.missed || a.eq.n.localeCompare(b.eq.n));

    if (!rows.length) { box.innerHTML = `<div class="card"><div class="empty"><span class="big">🔍</span>${esc(t('noneFound'))}</div></div>`; return; }

    const body = rows.map(({ eq, s }) => {
      let detail = '', att = '', ob = '';
      if (s.last) {
        const it = (state.records[s.last] || {}).items[eq.id];
        const rec = state.records[s.last];
        if (it) {
          detail = itemDoneChips(it);
          att = (rec && rec.attender) || '';
          ob = it.ob || '';
        }
      }
      return `<tr>
        <td data-label="${esc(t('equipmentNo'))}" style="font-weight:700">${esc(eq.n)}</td>
        <td data-label="${esc(t('type'))}" title="${esc(eq.t)}">${esc(tType(eq.t))}</td>
        <td data-label="${esc(t('durum'))}">${statusChip(s)}</td>
        <td data-label="${esc(t('sonBakim'))}">${s.last ? esc(fmtDate(s.last)) + ` <span class="hint">(${esc(fmtDaysAgo(s.missed))})</span>` : '—'}</td>
        <td data-label="${esc(t('detailsDone'))}"><div class="tag-row">${detail}</div></td>
        <td data-label="${esc(t('observation'))}">${esc(ob || '—')}</td>
        <td data-label="${esc(t('attender'))}">${esc(att || '—')}</td>
      </tr>`;
    }).join('');

    box.innerHTML = `
      <div class="card" style="padding:0;overflow:hidden">
        <div style="padding:12px 14px;border-bottom:1px solid var(--line)"><h2 style="margin:0">🕘 ${esc(t('sonBakim'))} <span class="count">${esc(t('lastPerEqSub'))}</span></h2></div>
        <div class="table-wrap">
          <table class="grid compact" style="min-width:1050px">
            <thead><tr>
              <th>${esc(t('equipmentNo'))}</th><th>${esc(t('type'))}</th><th>${esc(t('durum'))}</th>
              <th>${esc(t('sonBakim'))}</th><th>${esc(t('detailsDone'))}</th><th>${esc(t('observation'))}</th><th>${esc(t('attender'))}</th>
            </tr></thead>
            <tbody>${body}</tbody>
          </table>
        </div>
      </div>`;
  }

  function fmtDaysAgo(n) {
    if (n <= 0) return t('today');
    if (n === 1) return t('yesterday');
    return t('daysAgo', { n: n });
  }

  /* ================= sayfa: ekipmanlar ================= */
  function renderEquipment() {
    const types = allTypes();
    $('#main').innerHTML = `
      <h1 class="page-title">${esc(t('equipmentTitle'))}</h1>
      <p class="page-sub">${esc(t('equipmentSub', { n: state.equipment.length }))}</p>

      <div class="toolbar">
        <div class="field"><label>${esc(t('search'))}</label><input class="input" type="search" id="eqSearch" placeholder="${esc(t('searchPh'))}" value="${esc(ui.eqSearch)}" style="min-width:260px"></div>
        <div class="field"><label>${esc(t('type'))}</label>
          <select class="input" id="eqType">
            <option value="">${esc(t('allTypes'))}</option>
            ${types.map(x => `<option value="${esc(x)}" ${ui.eqType === x ? 'selected' : ''}>${esc(tType(x))}</option>`).join('')}
          </select>
        </div>
        <span class="hint" id="eqCount" style="padding-bottom:8px"></span>
        <div class="spacer"></div>
        <button class="btn" data-act="reset-seed" title="${esc(t('resetSeedDesc'))}">♻ ${esc(t('resetSeed'))}</button>
        <button class="btn primary" data-act="add-eq">＋ ${esc(t('addEquipment'))}</button>
      </div>

      <div id="eqTable"></div>`;
    renderEqTable();
  }

  function renderEqTable() {
    const st = statuses();
    const list = state.equipment.filter(eq => {
      if (ui.eqType && eq.t !== ui.eqType) return false;
      return eqMatches(eq, ui.eqSearch);
    });
    const c = $('#eqCount');
    if (c) c.textContent = t('showing', { a: list.length, b: state.equipment.length });

    if (!list.length) {
      $('#eqTable').innerHTML = `<div class="card"><div class="empty"><span class="big">🚜</span>${esc(t('noneFound'))}</div></div>`;
      return;
    }
    const rows = list.map(eq => {
      const s = st.byEq[eq.id];
      const fc = faultCountFor(eq.n);
      return `<tr>
        <td data-label="${esc(t('equipmentNo'))}" style="font-weight:700">${esc(eq.n)}</td>
        <td data-label="${esc(t('type'))}" title="${esc(eq.t)}">${esc(tType(eq.t))}</td>
        <td data-label="${esc(t('brand'))}">${esc(eq.b || '—')}</td>
        <td data-label="${esc(t('model'))}">${esc(eq.m || '—')}</td>
        <td data-label="${esc(t('spec'))}" class="hint">${esc(eq.s || '—')}</td>
        <td data-label="${esc(t('durum'))}">${statusChip(s)}</td>
        <td data-label="${esc(t('sonBakim'))}">${s.last ? esc(fmtDate(s.last)) : '—'}</td>
        <td class="num" data-label="${esc(t('faultsShort'))}"><button class="btn sm ${fc ? '' : 'ghost'}" data-act="fault-hist" data-no="${esc(eq.n)}" title="${esc(t('faultHistory'))}">🚨 ${fc}</button></td>
        <td class="num"><button class="btn sm ghost-danger" data-act="del-eq" data-no="${esc(eq.n)}">🗑 ${esc(t('del'))}</button></td>
      </tr>`;
    }).join('');

    $('#eqTable').innerHTML = `
      <div class="card" style="padding:0;overflow:hidden">
        <div class="table-wrap">
          <table class="grid compact" style="min-width:1020px">
            <thead><tr>
              <th>${esc(t('equipmentNo'))}</th><th>${esc(t('type'))}</th><th>${esc(t('brand'))}</th>
              <th>${esc(t('model'))}</th><th>${esc(t('spec'))}</th>              <th>${esc(t('durum'))}</th>
              <th>${esc(t('sonBakim'))}</th>
              <th class="num">🚨 ${esc(t('faultsShort'))}</th>
              <th class="num">${esc(t('actions'))}</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>`;
  }

  /* ================= sayfa: arızalar ================= */
  function fmtDateTime(dt) {
    if (!dt) return '—';
    const parts = String(dt).split('T');
    const date = /^\d{4}-\d{2}-\d{2}$/.test(parts[0]) ? fmtDate(parts[0]) : (parts[0] || '—');
    return parts[1] ? date + ' ' + parts[1].slice(0, 5) : date;
  }

  function faultDone(status) {
    const v = String(status || '').toLowerCase();
    return ['tamamlandi', 'tamamlandı', 'done', 'resolved', 'closed', 'kapandi', 'kapandı', 'cozuldu', 'çözüldü']
      .some(k => v.indexOf(k) !== -1);
  }

  function faultChip(status) {
    if (!status) return '<span class="chip neutral">—</span>';
    const v = String(status).toLowerCase();
    let cls = 'warn';
    if (faultDone(v)) cls = 'ok';
    else if (['açık', 'acik', 'open'].some(k => v.indexOf(k) !== -1)) cls = 'danger';
    return '<span class="chip ' + cls + '">' + esc(status) + '</span>';
  }

  function faultDuration(f) {
    if (!f.start || !f.end) return null;
    const s = Date.parse(f.start), e = Date.parse(f.end);
    if (isNaN(s) || isNaN(e) || e < s) return null;
    return Math.max(0, Math.round((e - s) / 3600000));
  }

  function faultsSorted() {
    return (state.faults || []).slice().sort((a, b) =>
      String(b.start || b.createdAt || '').localeCompare(String(a.start || a.createdAt || '')));
  }

  function faultsFiltered() {
    const q = ui.faultSearch.trim().toLowerCase();
    return faultsSorted().filter(f => {
      const done = faultDone(f.status);
      if (ui.faultFilter === 'active' && done) return false;
      if (ui.faultFilter === 'done' && !done) return false;
      if (q && [f.eq, f.report, f.desc, f.status, f.acts].join(' ').toLowerCase().indexOf(q) === -1) return false;
      return true;
    });
  }

  function renderFaults() {
    const all = state.faults || [];
    const month = todayISO().slice(0, 7);
    const active = all.filter(f => !faultDone(f.status)).length;
    const thisMonth = all.filter(f => String(f.start || f.createdAt || '').slice(0, 7) === month).length;

    $('#main').innerHTML = `
      <h1 class="page-title">${esc(t('faultsTitle'))}</h1>
      <p class="page-sub">${esc(t('faultsSub'))}</p>

      <div class="kpis">
        ${kpiBlock('info', t('faultTotal'), all.length, t('faultsCount', { n: all.length }))}
        ${kpiBlock('danger', t('faultActive'), active, t('faultActiveNote'))}
        ${kpiBlock('ok', t('faultDoneKpi'), all.length - active, t('faultDoneNote'))}
        ${kpiBlock('info', t('faultThisMonth'), thisMonth, t('faultThisMonthNote'))}
      </div>

      <div class="toolbar">
        <div class="field"><label>${esc(t('search'))}</label>
          <input class="input" type="search" id="faultSearch" placeholder="${esc(t('faultSearchPh'))}" value="${esc(ui.faultSearch)}" style="min-width:240px"></div>
        <div class="field"><label>${esc(t('fStatus'))}</label>
          <select class="input" id="faultFilter">
            <option value="">${esc(t('faultFilterAll'))}</option>
            <option value="active" ${ui.faultFilter === 'active' ? 'selected' : ''}>${esc(t('faultActiveF'))}</option>
            <option value="done" ${ui.faultFilter === 'done' ? 'selected' : ''}>${esc(t('faultDoneF'))}</option>
          </select></div>
        <span class="hint" id="faultCount" style="padding-bottom:8px"></span>
        <div class="spacer"></div>
        <button class="btn" data-act="export-faults">⬇ ${esc(t('exportFaults'))}</button>
        <button class="btn primary" data-act="add-fault">＋ ${esc(t('addFault'))}</button>
      </div>

      <div id="faultTable"></div>`;
    renderFaultTable();
  }

  function renderFaultTable() {
    const box = $('#faultTable');
    if (!box) return;
    const all = state.faults || [];
    const list = faultsFiltered();
    const c = $('#faultCount');
    if (c) c.textContent = t('faultsShowing', { a: list.length, b: all.length });

    if (!all.length) {
      box.innerHTML = `<div class="card"><div class="empty"><span class="big">🚨</span>${esc(t('emptyFaults'))}</div></div>`;
      return;
    }
    if (!list.length) {
      box.innerHTML = `<div class="card"><div class="empty"><span class="big">🔍</span>${esc(t('noneFound'))}</div></div>`;
      return;
    }

    const rows = list.map(f => {
      const dur = faultDuration(f);
      return `<tr>
        <td data-label="${esc(t('equipmentNo'))}" style="font-weight:700"><button class="eq-link" data-act="fault-hist" data-no="${esc(f.eq)}">${esc(f.eq)}</button></td>
        <td data-label="${esc(t('fieldReport'))}">${esc(f.report || '—')}</td>
        <td data-label="${esc(t('fieldFaultDesc'))}">${esc(f.desc || '—')}</td>
        <td data-label="${esc(t('fStatus'))}">${faultChip(f.status)}</td>
        <td data-label="${esc(t('fieldStart'))}">${esc(fmtDateTime(f.start))}</td>
        <td data-label="${esc(t('fieldEnd'))}">${esc(fmtDateTime(f.end))}</td>
        <td class="num" data-label="${esc(t('faultDur'))}">${dur === null ? '—' : esc(t('faultHours', { n: dur }))}</td>
        <td data-label="${esc(t('fieldActionsTaken'))}">${esc(f.acts || '—')}</td>
        <td class="num">
          <button class="btn sm" data-act="edit-fault" data-id="${esc(f.id)}">✏️ ${esc(t('edit'))}</button>
          <button class="btn sm ghost-danger" data-act="del-fault" data-id="${esc(f.id)}">🗑</button>
        </td>
      </tr>`;
    }).join('');

    box.innerHTML = `
      <div class="card" style="padding:0;overflow:hidden">
        <div class="table-wrap">
          <table class="grid compact" style="min-width:1150px">
            <thead><tr>
              <th>${esc(t('equipmentNo'))}</th>
              <th>${esc(t('fieldReport'))}</th>
              <th>${esc(t('fieldFaultDesc'))}</th>
              <th>${esc(t('fStatus'))}</th>
              <th>${esc(t('fieldStart'))}</th>
              <th>${esc(t('fieldEnd'))}</th>
              <th class="num">${esc(t('faultDur'))}</th>
              <th>${esc(t('fieldActionsTaken'))}</th>
              <th class="num">${esc(t('actions'))}</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>`;
  }

  function openFaultModal(id) {
    const f = id ? (state.faults || []).find(x => x.id === id) : null;
    const eqNos = state.equipment.map(e => e.n);
    const statusKeys = ['stOpen', 'stWaitParts', 'stProgress', 'stResolved', 'stRecur'];
    openModal({
      title: esc(f ? t('editFault') : t('addFault')),
      okLabel: f ? t('confirm') : t('addFault'),
      body: `
        <div class="field"><label>${esc(t('equipmentNo'))} *</label>
          <input class="input" id="fMachine" list="eqNoList" value="${esc(f ? f.eq : '')}" placeholder="${esc(t('fEqPh'))}" autocomplete="off">
          <datalist id="eqNoList">${eqNos.map(n => `<option value="${esc(n)}"></option>`).join('')}</datalist></div>
        <div class="field"><label>${esc(t('fieldReport'))}</label>
          <textarea class="input" id="fReport" rows="2" placeholder="${esc(t('fReportPh'))}">${esc(f ? f.report : '')}</textarea></div>
        <div class="field"><label>${esc(t('fieldFaultDesc'))}</label>
          <textarea class="input" id="fDesc" rows="2" placeholder="${esc(t('fDescPh'))}">${esc(f ? f.desc : '')}</textarea></div>
        <div class="field"><label>${esc(t('fStatus'))}</label>
          <input class="input" id="fStatusIn" list="statusList" value="${esc(f && f.status ? f.status : t('stOpen'))}" autocomplete="off">
          <datalist id="statusList">${statusKeys.map(k => `<option value="${esc(t(k))}"></option>`).join('')}</datalist></div>
        <div class="row">
          <div class="field grow"><label>${esc(t('fieldStart'))}</label>
            <input class="input" type="datetime-local" id="fStart" value="${esc(f ? f.start || '' : '')}"></div>
          <div class="field grow"><label>${esc(t('fieldEnd'))}</label>
            <input class="input" type="datetime-local" id="fEnd" value="${esc(f ? f.end || '' : '')}"></div>
        </div>
        <div class="field"><label>${esc(t('fieldActionsTaken'))}</label>
          <textarea class="input" id="fActs" rows="3" placeholder="${esc(t('fActionsPh'))}">${esc(f ? f.acts : '')}</textarea></div>
        <div class="err"></div>`,
      onOk: back => {
        const eq = $('#fMachine', back).value.trim();
        if (!eq) { modalErr(back, t('faultReq')); return false; }
        const data = {
          eq: eq,
          report: $('#fReport', back).value.trim(),
          desc: $('#fDesc', back).value.trim(),
          status: $('#fStatusIn', back).value.trim(),
          start: $('#fStart', back).value,
          end: $('#fEnd', back).value,
          acts: $('#fActs', back).value.trim()
        };
        if (f) {
          Object.assign(f, data);
        } else {
          state.faults = state.faults || [];
          state.faults.push(Object.assign({
            id: 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
            createdAt: todayISO()
          }, data));
        }
        save(true);
        closeModal();
        toast(t(f ? 'faultUpdated' : 'faultAdded'), 'ok');
        renderFaults();
        return true;
      }
    });
  }

  function confirmDeleteFault(id) {
    const f = (state.faults || []).find(x => x.id === id);
    if (!f) return;
    openModal({
      title: esc(t('delFaultTitle')),
      body: `<p>${esc(t('delFaultConfirm', { no: f.eq }))}</p>`,
      okLabel: t('del'),
      danger: true,
      onOk: () => {
        state.faults = (state.faults || []).filter(x => x.id !== id);
        save(true);
        closeModal();
        toast(t('faultRemoved'), 'ok');
        renderFaults();
        return true;
      }
    });
  }

  function faultCountFor(no) {
    return (state.faults || []).filter(f => f.eq === no).length;
  }

  function openFaultHistory(eqNo) {
    const list = (state.faults || [])
      .filter(f => f.eq === eqNo)
      .sort((a, b) => String(b.start || b.createdAt || '').localeCompare(String(a.start || a.createdAt || '')));
    const items = list.map(f => {
      const dur = faultDuration(f);
      return `<div class="fh-item">
        <div class="fh-head">
          ${faultChip(f.status)}
          <span class="fh-time">🕐 ${esc(fmtDateTime(f.start))} → ${esc(fmtDateTime(f.end))}</span>
          ${dur === null ? '' : `<span class="chip neutral">⏱ ${esc(t('faultHours', { n: dur }))}</span>`}
        </div>
        ${f.report ? `<div class="fh-line"><b>${esc(t('fhReport'))}:</b> ${esc(f.report)}</div>` : ''}
        ${f.desc ? `<div class="fh-line"><b>${esc(t('fhDesc'))}:</b> ${esc(f.desc)}</div>` : ''}
        ${f.acts ? `<div class="fh-line"><b>${esc(t('fhActs'))}:</b> ${esc(f.acts)}</div>` : ''}
      </div>`;
    }).join('');
    openModal({
      title: esc(t('faultHistoryFor', { no: eqNo })),
      body: `<p class="hint" style="margin:0 0 8px">${esc(t('faultsCount', { n: list.length }))}</p>` +
        (list.length
          ? `<div class="fh-list">${items}</div>`
          : `<div class="empty"><span class="big">🚨</span>${esc(t('noFaultHistory'))}</div>`),
      okLabel: t('close'),
      onOk: () => true
    });
  }

  function exportFaultsCsv() {
    const sep = ';';
    const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const head = [t('equipmentNo'), t('fieldReport'), t('fieldFaultDesc'), t('fStatus'), t('fieldStart'), t('fieldEnd'), t('faultDur'), t('fieldActionsTaken')];
    const lines = [head.map(q).join(sep)];
    faultsFiltered().forEach(f => {
      const dur = faultDuration(f);
      lines.push([
        f.eq, f.report, f.desc, f.status,
        f.start ? String(f.start).replace('T', ' ') : '',
        f.end ? String(f.end).replace('T', ' ') : '',
        dur === null ? '' : t('faultHours', { n: dur }),
        f.acts
      ].map(q).join(sep));
    });
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    downloadBlob(blob, 'ariza-takip_' + todayISO() + '.csv');
    toast(t('downloaded'), 'ok');
  }

  /* ================= sayfa: lastikler ================= */
  function tyresSorted() {
    return (state.tyres || []).slice().sort((a, b) =>
      String(b.date || '').localeCompare(String(a.date || '')) ||
      String(b.start || '').localeCompare(String(a.start || '')) ||
      (parseInt(b.no, 10) || 0) - (parseInt(a.no, 10) || 0));
  }

  function tyresFiltered() {
    const q = ui.tyreSearch.trim().toLowerCase();
    return tyresSorted().filter(r => {
      if (ui.tyreFrom && (!r.date || r.date < ui.tyreFrom)) return false;
      if (ui.tyreTo && (!r.date || r.date > ui.tyreTo)) return false;
      if (q && [r.plate, r.sticker, r.brand, r.size, r.serial, r.place, r.service, r.person, r.km]
        .join(' ').toLowerCase().indexOf(q) === -1) return false;
      return true;
    });
  }

  function nextTyreNo() {
    return (state.tyres || []).reduce((m, r) => Math.max(m, parseInt(r.no, 10) || 0), 0) + 1;
  }

  function tyrePlateList() {
    const set = {};
    (state.tyres || []).forEach(r => { if (r.plate) set[r.plate] = 1; });
    return Object.keys(set).sort();
  }

  function renderTyres() {
    const all = state.tyres || [];
    const month = todayISO().slice(0, 7);
    const today = todayISO();
    const monthN = all.filter(r => String(r.date || '').slice(0, 7) === month).length;
    const todayN = all.filter(r => r.date === today).length;
    const plates = tyrePlateList().length;

    $('#main').innerHTML = `
      <h1 class="page-title">${esc(t('tyresTitle'))}</h1>
      <p class="page-sub">${esc(t('tyresSub'))}</p>

      <div class="kpis">
        ${kpiBlock('info', t('tyreTotal'), all.length, t('tyresCount', { n: all.length }))}
        ${kpiBlock('ok', t('tyreMonth'), monthN, t('tyresCount', { n: monthN }))}
        ${kpiBlock('danger', t('tyreTodayKpi'), todayN, t('tyresCount', { n: todayN }))}
        ${kpiBlock('info', t('tyrePlates'), plates, t('platesNote', { n: plates }))}
      </div>

      <div class="toolbar">
        <div class="field"><label>${esc(t('search'))}</label>
          <input class="input" type="search" id="tyreSearch" placeholder="${esc(t('tyreSearchPh'))}" value="${esc(ui.tyreSearch)}" style="min-width:240px"></div>
        <div class="field"><label>${esc(t('from'))}</label>
          <input class="input" type="date" id="tyreFrom" value="${esc(ui.tyreFrom)}"></div>
        <div class="field"><label>${esc(t('to'))}</label>
          <input class="input" type="date" id="tyreTo" value="${esc(ui.tyreTo)}"></div>
        <span class="hint" id="tyreCount" style="padding-bottom:8px"></span>
        <div class="spacer"></div>
        <button class="btn" data-act="export-tyres">⬇ ${esc(t('exportTyres'))}</button>
        <button class="btn primary" data-act="add-tyre">＋ ${esc(t('addTyre'))}</button>
      </div>

      <div id="tyreTable"></div>`;
    renderTyreTable();
  }

  function renderTyreTable() {
    const box = $('#tyreTable');
    if (!box) return;
    const all = state.tyres || [];
    const list = tyresFiltered();
    const c = $('#tyreCount');
    if (c) c.textContent = t('tyresShowing', { a: list.length, b: all.length });

    if (!all.length) {
      box.innerHTML = `<div class="card"><div class="empty"><span class="big">🛞</span>${esc(t('emptyTyres'))}</div></div>`;
      return;
    }
    if (!list.length) {
      box.innerHTML = `<div class="card"><div class="empty"><span class="big">🔍</span>${esc(t('noneFound'))}</div></div>`;
      return;
    }

    const rows = list.map(r => `<tr>
      <td class="num" data-label="${esc(t('tColNo'))}" style="font-weight:700">${esc(r.no != null ? r.no : '—')}</td>
      <td data-label="${esc(t('date'))}">${esc(fmtDate(r.date))}</td>
      <td data-label="${esc(t('shift'))}">${esc(r.shift === 'night' ? t('shiftNight') : t('shiftDay'))}</td>
      <td data-label="${esc(t('attender'))}">${esc(r.person || '—')}</td>
      <td data-label="${esc(t('tColSticker'))}">${esc(r.sticker || '—')}</td>
      <td data-label="${esc(t('tColPlate'))}" style="font-weight:700">${esc(r.plate)}</td>
      <td class="num" data-label="${esc(t('tColKm'))}">${esc(r.km || '—')}</td>
      <td class="num" data-label="${esc(t('tColStart'))}">${esc(r.start || '—')}</td>
      <td class="num" data-label="${esc(t('tColFinish'))}">${esc(r.finish || '—')}</td>
      <td data-label="${esc(t('tColBrand'))}">${esc(r.brand || '—')}</td>
      <td data-label="${esc(t('tColSize'))}">${esc(r.size || '—')}</td>
      <td data-label="${esc(t('tColSerial'))}">${esc(r.serial || '—')}</td>
      <td data-label="${esc(t('tColPlace'))}">${esc(r.place || '—')}</td>
      <td data-label="${esc(t('tColService'))}">${esc(r.service || '—')}</td>
      <td class="num">
        <button class="btn sm" data-act="edit-tyre" data-id="${esc(r.id)}">✏️ ${esc(t('edit'))}</button>
        <button class="btn sm ghost-danger" data-act="del-tyre" data-id="${esc(r.id)}">🗑</button>
      </td>
    </tr>`).join('');

    box.innerHTML = `
      <div class="card" style="padding:0;overflow:hidden">
        <div class="table-wrap">
          <table class="grid compact" style="min-width:1500px">
            <thead><tr>
              <th class="num">${esc(t('tColNo'))}</th>
              <th>${esc(t('date'))}</th>
              <th>${esc(t('shift'))}</th>
              <th>${esc(t('attender'))}</th>
              <th>${esc(t('tColSticker'))}</th>
              <th>${esc(t('tColPlate'))}</th>
              <th class="num">${esc(t('tColKm'))}</th>
              <th class="num">${esc(t('tColStart'))}</th>
              <th class="num">${esc(t('tColFinish'))}</th>
              <th>${esc(t('tColBrand'))}</th>
              <th>${esc(t('tColSize'))}</th>
              <th>${esc(t('tColSerial'))}</th>
              <th>${esc(t('tColPlace'))}</th>
              <th>${esc(t('tColService'))}</th>
              <th class="num">${esc(t('actions'))}</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>`;
  }

  function openTyreModal(id) {
    const r = id ? (state.tyres || []).find(x => x.id === id) : null;
    const plates = tyrePlateList();
    openModal({
      title: esc(r ? t('editTyre') : t('addTyre')),
      okLabel: r ? t('confirm') : t('addTyre'),
      body: `
        <div class="row">
          <div class="field grow"><label>${esc(t('date'))} *</label>
            <input class="input" type="date" id="tyDate" value="${esc(r ? r.date || '' : todayISO())}" max="${todayISO()}"></div>
          <div class="field grow"><label>${esc(t('shift'))}</label>
            <select class="input" id="tyShift">
              <option value="day" ${!r || r.shift !== 'night' ? 'selected' : ''}>${esc(t('shiftDay'))}</option>
              <option value="night" ${r && r.shift === 'night' ? 'selected' : ''}>${esc(t('shiftNight'))}</option>
            </select></div>
        </div>
        <div class="field"><label>${esc(t('attender'))}</label>
          <input class="input" id="tyPerson" placeholder="${esc(t('attenderPh'))}" value="${esc(r ? r.person || '' : '')}" autocomplete="off"></div>
        <div class="row">
          <div class="field grow"><label>${esc(t('tColPlate'))} *</label>
            <input class="input" id="tyPlate" list="tyPlateList" placeholder="${esc(t('platePh'))}" value="${esc(r ? r.plate || '' : '')}" autocomplete="off">
            <datalist id="tyPlateList">${plates.map(p => `<option value="${esc(p)}"></option>`).join('')}</datalist></div>
          <div class="field grow"><label>${esc(t('tColSticker'))}</label>
            <input class="input" id="tySticker" placeholder="${esc(t('stickerPh'))}" value="${esc(r ? r.sticker || '' : '')}" autocomplete="off"></div>
        </div>
        <div class="row">
          <div class="field grow"><label>${esc(t('tColKm'))}</label>
            <input class="input" id="tyKm" placeholder="${esc(t('kmPh'))}" value="${esc(r ? r.km || '' : '')}" autocomplete="off"></div>
          <div class="field grow"><label>${esc(t('tColStart'))}</label>
            <input class="input" type="time" id="tyStart" value="${esc(r ? r.start || '' : '')}"></div>
          <div class="field grow"><label>${esc(t('tColFinish'))}</label>
            <input class="input" type="time" id="tyFinish" value="${esc(r ? r.finish || '' : '')}"></div>
        </div>
        <div class="row">
          <div class="field grow"><label>${esc(t('tColBrand'))}</label>
            <input class="input" id="tyBrand" placeholder="${esc(t('tyreBrandPh'))}" value="${esc(r ? r.brand || '' : '')}" autocomplete="off"></div>
          <div class="field grow"><label>${esc(t('tColSize'))}</label>
            <input class="input" id="tySize" placeholder="${esc(t('tyreSizePh'))}" value="${esc(r ? r.size || '' : '')}" autocomplete="off"></div>
        </div>
        <div class="row">
          <div class="field grow"><label>${esc(t('tColSerial'))}</label>
            <input class="input" id="tySerial" placeholder="${esc(t('serialPh'))}" value="${esc(r ? r.serial || '' : '')}" autocomplete="off"></div>
          <div class="field grow"><label>${esc(t('tColPlace'))}</label>
            <input class="input" id="tyPlace" placeholder="${esc(t('placePh'))}" value="${esc(r ? r.place || '' : '')}" autocomplete="off"></div>
        </div>
        <div class="field"><label>${esc(t('tColService'))}</label>
          <textarea class="input" id="tyService" rows="2" placeholder="${esc(t('servicePh'))}">${esc(r ? r.service || '' : '')}</textarea></div>
        <div class="err"></div>`,
      onOk: back => {
        const date = $('#tyDate', back).value;
        const plate = $('#tyPlate', back).value.trim();
        if (!date || !plate) { modalErr(back, t('tyreReq')); return false; }
        const data = {
          date: date,
          shift: $('#tyShift', back).value === 'night' ? 'night' : 'day',
          person: $('#tyPerson', back).value.trim(),
          plate: plate,
          sticker: $('#tySticker', back).value.trim(),
          km: $('#tyKm', back).value.trim(),
          start: $('#tyStart', back).value,
          finish: $('#tyFinish', back).value,
          brand: $('#tyBrand', back).value.trim(),
          size: $('#tySize', back).value.trim(),
          serial: $('#tySerial', back).value.trim(),
          place: $('#tyPlace', back).value.trim(),
          service: $('#tyService', back).value.trim()
        };
        if (r) {
          Object.assign(r, data);
        } else {
          state.tyres = state.tyres || [];
          state.tyres.push(Object.assign({
            id: 'y' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
            no: nextTyreNo(),
            createdAt: todayISO()
          }, data));
        }
        save(true);
        closeModal();
        toast(t(r ? 'tyreUpdated' : 'tyreAdded'), 'ok');
        renderTyres();
        return true;
      }
    });
  }

  function confirmDeleteTyre(id) {
    const r = (state.tyres || []).find(x => x.id === id);
    if (!r) return;
    openModal({
      title: esc(t('delTyreTitle')),
      body: `<p>${esc(t('delTyreConfirm', { no: r.no != null ? r.no : '—' }))}</p>`,
      okLabel: t('del'),
      danger: true,
      onOk: () => {
        state.tyres = (state.tyres || []).filter(x => x.id !== id);
        save(true);
        closeModal();
        toast(t('tyreRemoved'), 'ok');
        renderTyres();
        return true;
      }
    });
  }

  function exportTyresCsv() {
    const sep = ';';
    const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const head = [t('tColNo'), t('date'), t('shift'), t('attender'), t('tColSticker'), t('tColPlate'),
      t('tColKm'), t('tColStart'), t('tColFinish'), t('tColBrand'), t('tColSize'),
      t('tColSerial'), t('tColPlace'), t('tColService')];
    const lines = [head.map(q).join(sep)];
    tyresFiltered().forEach(r => {
      lines.push([
        r.no, r.date, r.shift === 'night' ? t('shiftNight') : t('shiftDay'), r.person,
        r.sticker, r.plate, r.km, r.start, r.finish,
        r.brand, r.size, r.serial, r.place, r.service
      ].map(q).join(sep));
    });
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    downloadBlob(blob, 'lastik-takip_' + todayISO() + '.csv');
    toast(t('downloaded'), 'ok');
  }

  /* ================= sayfa: ayarlar ================= */
  function renderSettings() {
    let recCount = 0, visitCount = 0;
    for (const d in state.records) {
      recCount++;
      visitCount += visitsOn(d);
    }
    $('#main').innerHTML = `
      <h1 class="page-title">${esc(t('settingsTitle'))}</h1>
      <p class="page-sub">${esc(t('settingsSub'))}</p>

      <div class="card">
        <h2>🌐 ${esc(t('language'))}</h2>
        <div class="row">
          <div class="lang-switch" style="background:var(--neutral-bg)">
            <button class="${state.lang === 'tr' ? 'active' : ''}" data-act="lang" data-lang="tr" style="color:inherit">TR</button>
            <button class="${state.lang === 'en' ? 'active' : ''}" data-act="lang" data-lang="en" style="color:inherit">EN</button>
          </div>
        </div>
        <div class="sep"></div>
        <div class="set-row">
          <div>
            <div class="s-label">⚠ ${esc(t('warnDaysLabel'))}</div>
            <div class="s-desc">${esc(t('warnDaysDesc'))}</div>
          </div>
          <input class="input" type="number" id="warnDays" min="1" max="30" value="${parseInt(state.settings.warnDays, 10) || 2}" style="width:90px">
        </div>
      </div>

      <div class="card">
        <h2>💾 ${esc(t('dataStats'))}</h2>
        <div class="kpis" style="margin-bottom:0">
          ${kpiBlock('info', t('statEquip'), state.equipment.length, t('count', { n: state.equipment.length }))}
          ${kpiBlock('ok', t('statRecords'), recCount, t('viewDays'))}
          ${kpiBlock('info', t('statVisits'), visitCount, t('kpiVisited'))}
        </div>
        <div class="sep"></div>
        <div class="row">
          <button class="btn" data-act="backup">⬇ ${esc(t('backup'))}</button>
          <button class="btn" data-act="restore">⬆ ${esc(t('restore'))}</button>
          <div class="spacer"></div>
          <button class="btn ghost-danger" data-act="clear-records">🗑 ${esc(t('clearRecords'))}</button>
        </div>
        <p class="hint" style="margin-bottom:0">${esc(t('storageInfo'))}<br>${esc(t('clearRecordsDesc'))}</p>
      </div>

      <div class="card">
        <h2>📦 ${esc(t('dlCardTitle'))}</h2>
        <div class="row">
          <button class="btn" data-act="download-app">⬇ ${esc(t('dlApp'))}</button>
          <a class="btn" href="gunluk-bakim-kaynak.zip" download="gunluk-bakim-kaynak.zip">⬇ ${esc(t('dlSource'))}</a>
        </div>
        <p class="hint" style="margin-bottom:0">${esc(t('dlInfo'))}</p>
      </div>`;
  }

  /* ================= modal ================= */
  function openModal(opts) {
    closeModal();
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.id = 'modalRoot';
    back.innerHTML = `
      <div class="modal" role="dialog">
        <div class="m-head">${opts.title}</div>
        <div class="m-body">${opts.body}</div>
        <div class="m-foot">
          <button class="btn" data-modal="cancel">${esc(t('cancel'))}</button>
          ${opts.okLabel ? `<button class="btn ${opts.danger ? 'danger' : 'primary'}" data-modal="ok">${esc(opts.okLabel)}</button>` : ''}
        </div>
      </div>`;
    document.body.appendChild(back);
    back.addEventListener('click', e => {
      if (e.target === back) closeModal();
      const b = e.target.closest('[data-modal]');
      if (!b) return;
      if (b.dataset.modal === 'cancel') closeModal();
      if (b.dataset.modal === 'ok' && opts.onOk) {
        const res = opts.onOk(back);
        if (res !== false) closeModal();
      }
    });
    const first = back.querySelector('input,select,textarea');
    if (first) setTimeout(() => first.focus(), 60);
    return back;
  }
  function closeModal() { const m = document.getElementById('modalRoot'); if (m) m.remove(); }
  function modalErr(back, msg) { const e = back.querySelector('.err'); if (e) e.textContent = msg || ''; }

  function openAddEquipment() {
    const types = allTypes();
    openModal({
      title: esc(t('addTitle')),
      okLabel: t('addEquipment'),
      body: `
        <div class="field"><label>${esc(t('equipmentNo'))} *</label>
          <input class="input" id="fNo" placeholder="BD-014" autocomplete="off"></div>
        <div class="field"><label>${esc(t('type'))}</label>
          <input class="input" id="fType" list="typeList" placeholder="${esc(t('typePh'))}" autocomplete="off">
          <datalist id="typeList">${types.map(x => `<option value="${esc(x)}"></option>`).join('')}</datalist></div>
        <div class="row">
          <div class="field grow"><label>${esc(t('brand'))}</label><input class="input" id="fBrand" autocomplete="off"></div>
          <div class="field grow"><label>${esc(t('model'))}</label><input class="input" id="fModel" autocomplete="off"></div>
        </div>
        <div class="field"><label>${esc(t('spec'))}</label><input class="input" id="fSpec" autocomplete="off"></div>
        <div class="err"></div>`,
      onOk: back => {
        const no = $('#fNo', back).value.trim();
        const type = $('#fType', back).value.trim();
        const brand = $('#fBrand', back).value.trim();
        const model = $('#fModel', back).value.trim();
        const spec = $('#fSpec', back).value.trim();
        if (!no) { modalErr(back, t('noRequired')); return false; }
        if (state.equipment.some(e => e.id.toLowerCase() === no.toLowerCase())) { modalErr(back, t('noExists')); return false; }
        state.equipment.push({ id: no, n: no, t: type, b: brand, m: model, s: spec, createdAt: todayISO() });
        state.removed = state.removed.filter(x => x !== no);
        save(true);
        closeModal();
        toast(t('eqAdded', { no: no }), 'ok');
        if (ui.page === 'equipment') renderEquipment(); else render();
        updateTodayStats();
        return true;
      }
    });
  }

  function confirmDeleteEquipment(no) {
    openModal({
      title: esc(t('deleteTitle')),
      body: `<p>${esc(t('deleteConfirm', { no: no }))}</p>`,
      okLabel: t('del'),
      danger: true,
      onOk: () => {
        state.equipment = state.equipment.filter(e => e.id !== no);
        if (state.removed.indexOf(no) === -1) state.removed.push(no);
        save(true);
        closeModal();
        toast(t('eqRemoved', { no: no }), 'ok');
        render();
        return true;
      }
    });
  }

  /* ================= dışa aktarma ================= */
  function downloadBlob(blob, name) {
    const a = document.createElement('a');
    const url = URL.createObjectURL(blob);
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function exportCsv() {
    const sep = ';';
    const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const head = [t('date'), t('attender'), t('shift'), t('equipmentNo'), t('type'), t('brand'), t('model'), t('visited'), t('greasing'), t('airFilter'), t('oils'), t('hours'), t('location'), t('observation')];
    const lines = [head.map(q).join(sep)];
    const dates = histFilteredDates().slice().sort();
    for (const d of dates) {
      const r = state.records[d];
      for (const id of Object.keys(r.items).sort()) {
        const it = r.items[id];
        const eq = eqById(id);
        lines.push([
          d, r.attender || '', r.shift === 'night' ? t('shiftNight') : t('shiftDay'),
          id, eq ? eq.t : '', eq ? eq.b : '', eq ? eq.m : '',
          it.v ? '✔' : '', it.g ? '✔' : '', it.af ? '✔' : '',
          Object.keys(it.o || {}).filter(k => it.o[k]).map(k => {
            const v = it.o[k];
            const q = (v && typeof v === 'object') ? v.q : '';
            return q ? k + ': ' + q + ' L' : k;
          }).join(' / '),
          it.h || '', it.loc || '', it.ob || ''
        ].map(q).join(sep));
      }
    }
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    downloadBlob(blob, 'gunluk-bakim_' + todayISO() + '.csv');
    toast(t('downloaded'), 'ok');
  }

  /* uygulamanın kendisini (tek dosya HTML) indir */
  function downloadApp() {
    fetch(location.pathname + '?dl=' + Date.now(), { cache: 'no-store' })
      .then(r => { if (!r.ok) throw new Error('http ' + r.status); return r.blob(); })
      .then(b => { downloadBlob(b, 'gunluk-bakim.html'); toast(t('downloaded'), 'ok'); })
      .catch(() => {
        try {
          const html = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
          downloadBlob(new Blob([html], { type: 'text/html;charset=utf-8' }), 'gunluk-bakim.html');
          toast(t('downloaded'), 'ok');
        } catch (e) { toast(t('dlErr'), 'err'); }
      });
  }

  function backupJson() {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    downloadBlob(blob, 'gunluk-bakim-yedek_' + todayISO() + '.json');
    toast(t('downloaded'), 'ok');
  }

  function restoreJson() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = '.json,application/json';
    inp.addEventListener('change', () => {
      const f = inp.files && inp.files[0];
      if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        try {
          const st = JSON.parse(rd.result);
          if (!st || !Array.isArray(st.equipment)) throw new Error('bad');
          st.settings = Object.assign({ warnDays: 2 }, st.settings || {});
          st.removed = Array.isArray(st.removed) ? st.removed : [];
          st.records = st.records && typeof st.records === 'object' ? st.records : {};
          st.faults = Array.isArray(st.faults) ? st.faults : [];
          st.tyres = Array.isArray(st.tyres) ? st.tyres : [];
          st.lang = st.lang === 'en' ? 'en' : state.lang;
          state = st;
          save(true);
          render();
          toast(t('restoreDone'), 'ok');
        } catch (e) {
          toast(t('restoreErr'), 'err');
        }
      };
      rd.onerror = () => toast(t('restoreErr'), 'err');
      rd.readAsText(f);
    });
    inp.click();
  }

  /* ================= render ================= */
  function renderChrome() {
    const st = statuses();
    const warn = st.warnCount;
    $('#nav').innerHTML = `
      <button data-act="nav" data-page="today" class="${ui.page === 'today' ? 'active' : ''}">🏠 ${esc(t('navToday'))} <span class="badge" id="navBadge" style="display:${warn ? 'inline-block' : 'none'}">${warn}</span></button>
      <button data-act="nav" data-page="faults" class="${ui.page === 'faults' ? 'active' : ''}">🚨 ${esc(t('navFaults'))}</button>
      <button data-act="nav" data-page="tyres" class="${ui.page === 'tyres' ? 'active' : ''}">🚗 ${esc(t('navTyres'))}</button>
      <button data-act="nav" data-page="history" class="${ui.page === 'history' ? 'active' : ''}">🕘 ${esc(t('navHistory'))}</button>
      <button data-act="nav" data-page="equipment" class="${ui.page === 'equipment' ? 'active' : ''}">🚜 ${esc(t('navEquipment'))}</button>
      <button data-act="nav" data-page="settings" class="${ui.page === 'settings' ? 'active' : ''}">⚙️ ${esc(t('navSettings'))}</button>`;
    $('#langSwitch').innerHTML = `
      <button data-act="lang" data-lang="tr" class="${state.lang === 'tr' ? 'active' : ''}">TR</button>
      <button data-act="lang" data-lang="en" class="${state.lang === 'en' ? 'active' : ''}">EN</button>`;
    $('#brandTitle').textContent = t('appTitle');
    $('#brandSub').textContent = t('appSub');
    document.documentElement.lang = state.lang;
    document.title = t('appTitle');
  }

  function render() {
    renderChrome();
    if (ui.page === 'today') renderToday();
    else if (ui.page === 'faults') renderFaults();
    else if (ui.page === 'tyres') renderTyres();
    else if (ui.page === 'history') renderHistory();
    else if (ui.page === 'equipment') renderEquipment();
    else renderSettings();
    if (ui.refocus) {
      const el = document.getElementById(ui.refocus);
      if (el) { el.focus(); try { el.setSelectionRange(el.value.length, el.value.length); } catch (e) { /* number input */ } }
      ui.refocus = null;
    }
  }

  function refreshRow(id) {
    const tr = $(`tr[data-row="${CSS.escape(id)}"]`);
    if (!tr) return;
    const it = getItem(ui.date, id, false);
    tr.classList.toggle('visited', !!(it && it.v));
  }

  /* ================= olaylar ================= */
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const act = el.dataset.act;

    switch (act) {
      case 'nav':
        ui.page = el.dataset.page;
        ui.refocus = null;
        rememberPage(ui.page);
        render();
        window.scrollTo({ top: 0 });
        break;

      case 'lang':
        state.lang = el.dataset.lang === 'en' ? 'en' : 'tr';
        save(true);
        render();
        break;

      case 'date-prev':
        ui.date = addDays(ui.date, -1);
        renderToday();
        break;
      case 'date-next':
        if (ui.date < todayISO()) { ui.date = addDays(ui.date, 1); renderToday(); }
        break;
      case 'date-today':
        ui.date = todayISO();
        renderToday();
        break;

      case 'mark-all': {
        const list = todayFilterList();
        list.forEach(eq => { getItem(ui.date, eq.id, true).v = 1; });
        save(true);
        renderTodayTable();
        updateTodayStats();
        break;
      }
      case 'unmark-all': {
        const list = todayFilterList();
        list.forEach(eq => { const it = getItem(ui.date, eq.id, false); if (it) it.v = 0; });
        save(true);
        renderTodayTable();
        updateTodayStats();
        break;
      }

      case 'jump': {
        ui.search = el.dataset.no;
        ui.type = '';
        ui.onlyMissing = false;
        ui.page = 'today';
        render();
        setTimeout(() => focusRow(el.dataset.no), 80);
        break;
      }

      case 'hist-view':
        ui.histView = el.dataset.view;
        renderHistory();
        break;

      case 'alerts-toggle':
        ui.alertsExpanded = !ui.alertsExpanded;
        updateTodayStats();
        break;

      case 'toggle-row': {
        const tr = el.closest('tr');
        if (tr) tr.classList.toggle('open');
        break;
      }

      case 'export-csv': exportCsv(); break;
      case 'backup': backupJson(); break;
      case 'restore': restoreJson(); break;
      case 'download-app': downloadApp(); break;

      case 'add-fault': openFaultModal(); break;
      case 'edit-fault': openFaultModal(el.dataset.id); break;
      case 'del-fault': confirmDeleteFault(el.dataset.id); break;
      case 'fault-hist': openFaultHistory(el.dataset.no); break;
      case 'export-faults': exportFaultsCsv(); break;

      case 'add-tyre': openTyreModal(); break;
      case 'edit-tyre': openTyreModal(el.dataset.id); break;
      case 'del-tyre': confirmDeleteTyre(el.dataset.id); break;
      case 'export-tyres': exportTyresCsv(); break;

      case 'add-eq': openAddEquipment(); break;
      case 'del-eq': confirmDeleteEquipment(el.dataset.no); break;

      case 'reset-seed': {
        openModal({
          title: esc(t('resetSeed')),
          body: `<p>${esc(t('resetSeedDesc'))}</p>`,
          okLabel: t('confirm'),
          onOk: () => {
            let added = 0;
            (window.EQUIPMENT_SEED || []).forEach(e => {
              if (state.removed.indexOf(e.n) !== -1) return;
              if (state.equipment.some(x => x.id === e.n)) return;
              state.equipment.push({ id: e.n, n: e.n, t: e.t, b: e.b, m: e.m, s: e.s });
              added++;
            });
            save(true);
            closeModal();
            toast(t('resetSeedDone') + ' (+' + added + ')', 'ok');
            render();
            return true;
          }
        });
        break;
      }

      case 'clear-records': {
        openModal({
          title: esc(t('clearRecords')),
          body: `<p>${esc(t('clearConfirm'))}</p>`,
          okLabel: t('del'),
          danger: true,
          onOk: () => {
            state.records = {};
            save(true);
            closeModal();
            toast(t('cleared'), 'ok');
            render();
            return true;
          }
        });
        break;
      }
    }
  });

  /* checkbox / select / date değişimleri */
  document.addEventListener('change', e => {
    const el = e.target;

    if (el.id === 'datePick') {
      ui.date = el.value || todayISO();
      if (ui.date > todayISO()) ui.date = todayISO();
      renderToday();
      return;
    }
    if (el.id === 'attenderInput') return; /* input event handles */
    if (el.id === 'shiftSelect') {
      const r = getRecord(ui.date, true);
      r.shift = el.value;
      save(true);
      return;
    }
    if (el.id === 'onlyMissing') { ui.onlyMissing = el.checked; renderTodayTable(); return; }
    if (el.id === 'todayType') { ui.type = el.value; renderTodayTable(); return; }
    if (el.id === 'eqType') { ui.eqType = el.value; renderEqTable(); return; }
    if (el.id === 'faultFilter') { ui.faultFilter = el.value; renderFaultTable(); return; }
    if (el.id === 'tyreFrom') { ui.tyreFrom = el.value; renderTyreTable(); return; }
    if (el.id === 'tyreTo') { ui.tyreTo = el.value; renderTyreTable(); return; }
    if (el.id === 'warnDays') {
      state.settings.warnDays = Math.min(30, Math.max(1, parseInt(el.value, 10) || 2));
      el.value = state.settings.warnDays;
      save(true);
      renderChrome();
      return;
    }
    if (el.id === 'histFrom') { ui.histFrom = el.value; renderHistList(); return; }
    if (el.id === 'histTo') { ui.histTo = el.value; renderHistList(); return; }

    const f = el.dataset && el.dataset.f;
    if (!f) return;
    const id = el.dataset.id;
    if (f === 'oil') {
      const it = getItem(ui.date, id, true);
      if (el.checked) { it.o[el.dataset.oil] = 1; it.v = 1; }
      else delete it.o[el.dataset.oil];
      const vCb = $(`tr[data-row="${CSS.escape(id)}"] [data-f="v"]`);
      if (vCb) vCb.checked = !!it.v;
      afterItemChange(id);
      return;
    }
    if (f === 'v' || f === 'g' || f === 'af') {
      const it = getItem(ui.date, id, true);
      it[f] = el.checked ? 1 : 0;
      if ((f === 'g' || f === 'af') && el.checked && !it.v) {
        it.v = 1;
        const vCb = $(`tr[data-row="${CSS.escape(id)}"] [data-f="v"]`);
        if (vCb) vCb.checked = true;
      }
      afterItemChange(id);
      return;
    }
  });

  function afterItemChange(id) {
    refreshRow(id);
    updateTodayStats();
    save();
  }

  /* metin girdileri */
  document.addEventListener('input', e => {
    const el = e.target;

    if (el.id === 'attenderInput') {
      const v = el.value;
      if (v.trim()) { const r = getRecord(ui.date, true); r.attender = v; save(); }
      else { const r = getRecord(ui.date, false); if (r) { r.attender = ''; save(); } }
      return;
    }
    if (el.id === 'todaySearch') { ui.search = el.value; ui.refocus = 'todaySearch'; renderTodayTable(); return; }
    if (el.id === 'eqSearch') { ui.eqSearch = el.value; ui.refocus = 'eqSearch'; renderEqTable(); return; }
    if (el.id === 'faultSearch') { ui.faultSearch = el.value; ui.refocus = 'faultSearch'; renderFaultTable(); return; }
    if (el.id === 'tyreSearch') { ui.tyreSearch = el.value; ui.refocus = 'tyreSearch'; renderTyreTable(); return; }
    if (el.id === 'histSearch') {
      ui.histSearch = el.value;
      ui.refocus = 'histSearch';
      renderHistList();
      return;
    }

    const f = el.dataset && el.dataset.f;
    if (!f || f === 'v' || f === 'g' || f === 'af' || f === 'oil') return;
    const id = el.dataset.id;
    const it = getItem(ui.date, id, true);

    if (f === 'oilq') {
      /* yağ miktarı (litre): değer girilince yağ "kullanıldı" olur */
      const name = el.dataset.oil;
      const raw = el.value.trim();
      if (raw === '') {
        if (it.o[name]) it.o[name] = 1;
      } else {
        it.o[name] = { u: 1, q: raw };
        it.v = 1;
      }
      const oilCb = $(`tr[data-row="${CSS.escape(id)}"] [data-f="oil"][data-oil="${name}"]`);
      if (oilCb) oilCb.checked = !!it.o[name];
      const vCb = $(`tr[data-row="${CSS.escape(id)}"] [data-f="v"]`);
      if (vCb) vCb.checked = !!it.v;
      afterItemChange(id);
      return;
    }

    it[f] = el.value;
    save();
  });

  /* kısayollar */
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeModal();
  });

  /* ================= başlat ================= */
  window.addEventListener('hashchange', () => {
    const p = location.hash.slice(1);
    if (PAGES.indexOf(p) !== -1 && p !== ui.page) {
      ui.page = p;
      rememberPage(p);
      render();
      window.scrollTo({ top: 0 });
    }
  });

  function boot() {
    state = load();
    ui.date = todayISO();
    ui.page = pageFromStart();
    render();
  }
  boot();
})();
