#!/usr/bin/env bash
# index.html'i kaynak dosyalardan derler: template.html + style.css + js/*.js
set -e
cd "$(dirname "$0")"

tmp="index.html.build"
: > "$tmp"

while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in
    '/*__STYLE__*/'*) cat style.css >> "$tmp" ;;
    '/*__DATA__*/'*)  cat js/data.js >> "$tmp" ;;
    '/*__I18N__*/'*)  cat js/i18n.js >> "$tmp" ;;
    '/*__APP__*/'*)   cat js/app.js >> "$tmp" ;;
    *) printf '%s\n' "$line" >> "$tmp" ;;
  esac
done < template.html

mv "$tmp" index.html
echo "OK: index.html $(wc -c < index.html) bytes"
