# Uygulamayı Ücretsiz İnternette Yayına Alma — GitHub Pages

## ✅ YAYINDA (3 Ekim 2026)

| | |
|---|---|
| **Site adresi** | https://cem3302.github.io/gunluk-bakim/ |
| **Depo** | https://github.com/Cem3302/gunluk-bakim |
| **Hosting** | GitHub Pages (ücretsiz, HTTPS dahil) |
| **Alan adı** | `cem3302.github.io` alt alan adı (ücretsiz) |

**Güncelleme:** Yerel depo `gunluk-bakim/site/` klasöründedir ve bilgisayarınızdaki
GitHub kimliği kayıtlıdır. Yeni sürümü yayına almak için: `site/index.html`
güncellenir → `git commit` → `git push` → ~1 dakika içinde site yenilenir.

**Veri:** Canlı sitenin verisi her cihazın kendi tarayıcısında tutulur (temiz
başlangıç). Cihazlar arası taşımak için Ayarlar → Yedekleme (JSON) / CSV.

---

## Aşağıdaki adımlar elle yayınlama rehberidir (artık gerek yok)

Bu klasördeki **tek dosyalık** uygulamayı (`index.html`) ücretsiz hosting +
ücretsiz alan adıyla (`https://<kullaniciadi>.github.io/gunluk-bakim/`)
yayına almak için aşağıdaki adımları izleyin. Toplam süre ~5 dakika.
Kod bilmek gerekmez, hiçbir ücret ödemezsiniz.

> Hazır paket: `deploy/gunluk-bakim.zip` (veya içindeki `deploy/index.html`)

## 1) GitHub hesabı açın (ücretsiz)

1. https://github.com → **Sign up**
2. E-posta, şifre ve bir **kullanıcı adı** seçin.
   - ⚠️ Bu kullanıcı adı sitenizin adresi olacak: `https://<kullaniciadi>.github.io/...`
     Uygun bir adres seçtiğinizden emin olun.
3. E-postadaki doğrulama kodunu girin, hesabı tamamlayın.

## 2) Yeni depo (repository) oluşturun

1. Giriş yaptıktan sonra sağ üstteki **+** → **New repository**
2. Repository name: `gunluk-bakim`
3. **Public** seçin (Private olursa ücretsiz hesapta Pages çalışmaz)
4. Diğer ayarlara dokunmadan **Create repository** deyin.

## 3) index.html dosyasını yükleyin

1. Açılan depo sayfasında **Add file → Upload files**
2. Bu klasördeki `deploy/index.html` dosyasını (veya `gunluk-bakim.zip`
   içindekini) tarayıcı penceresine sürükleyin
3. Altta **Commit changes** deyin.

## 4) GitHub Pages'i açın

1. Depo sayfasında üst menüden **Settings** (sol menüde en altta **Pages**)
2. **Build and deployment** bölümünde:
   - Source: **Deploy from a branch**
   - Branch: **main** / **/ (root)** → **Save**
3. 1–2 dakika bekleyin; sayfa yenilendiğinde üstte yeşil kutu çıkar:
   **"Your site is live at https://<kullaniciadi>.github.io/gunluk-bakim/"**

Adresinizi ekibinizle paylaşın; telefon ekranına da eklenebilir
(Tarayıcı → "Ana ekrana ekle").

## 5) Güncelleme yaparken

Uygulamada değişiklik olduğunda (ör. yeni özellik derlendikten sonra)
`index.html` dosyasını tekrar yükleyin: depo → **Add file → Upload files** →
dosyayı sürükle → **Commit changes**. ~1 dakika sonra site güncellenir.

## Sık karşılaşılan sorular

- **Ücret var mı?** Yok. Hosting, HTTPS ve `*.github.io` alt alan adı ücretsizdir.
- **Kendi alan adım olsun** (ör. `bakim.sirketim.com`): Domaini bir kayıt
  firmasından aldıktan sonra Settings → Pages → **Custom domain** alanına
  yazıp DNS'te CNAME kaydını GitHub'a yönlendirirsiniz; bağlama ücretsizdir.
- **Veriler nerede?** Veriler *ziyaret eden cihazın tarayıcısında*
  (localStorage) tutulur. Her cihaz kendi kaydını görür; aynı veriyi
  paylaşmak için Ayarlar → **Yedeği indir / Geri yükle** (JSON) kullanın
  veya kayıtları CSV indirip paylaşın. Tüm cihazda ortak veri istenirse
  ileride sunucu (backend) eklenmelidir.
- **Yayın silmek/gizlemek** için: Settings → General → **Delete repository**.

## Alternatif platformlar (hepsi ücretsiz)

- **Netlify** — netlify.com/drop adresine klasörü sürükleyin, kod gerekmez,
  adres `*.netlify.app` olur.
- **Cloudflare Pages** — dash.cloudflare.com → Pages → oluştur, `*.pages.dev`.
- **Vercel** — vercel.com → GitHub ile giriş → tek tık, `*.vercel.app`.
